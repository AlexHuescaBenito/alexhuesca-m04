/*
1.Agafa el fitxer de base DOMExercici1.html. Crea un fitxer .js i fes-lo enllaçar amb el
fitxer html. Fes que el fitxer .js modifiqui l’estil de paràgraf tot utilitzant el botó.
*/
function estiljs(){
document.getElementById("text").style.fontSize = "X-Large";
}